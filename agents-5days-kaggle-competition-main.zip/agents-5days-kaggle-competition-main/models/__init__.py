"""Machine learning models for prediction."""

