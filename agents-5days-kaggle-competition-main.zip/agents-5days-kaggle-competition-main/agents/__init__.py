"""Agent modules for the stock prediction system."""

