"""Utility scripts for agent management."""

