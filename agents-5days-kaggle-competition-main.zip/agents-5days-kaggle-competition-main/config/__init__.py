"""Configuration module for Stock Prediction System."""

